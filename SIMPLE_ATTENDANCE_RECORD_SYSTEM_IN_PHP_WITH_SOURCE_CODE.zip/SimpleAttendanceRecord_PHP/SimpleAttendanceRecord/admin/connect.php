<?php
	$conn = new mysqli('localhost', 'root', '', 'db_sars') or die(mysqli_error());